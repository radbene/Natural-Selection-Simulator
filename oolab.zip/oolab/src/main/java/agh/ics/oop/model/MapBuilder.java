package agh.ics.oop.model;

public class MapBuilder {
    public MapBuilder() {
    }

    public AbstractWorldMap createMap(WorldConfig config) {
        // TODO: Placeholder
        return new RectangularMap(10, 10);
    }
}
