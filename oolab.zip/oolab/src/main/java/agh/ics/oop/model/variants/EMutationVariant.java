package agh.ics.oop.model.variants;

public enum EMutationVariant {
    STANDARD,
    SMALL_SHIFT;
}
