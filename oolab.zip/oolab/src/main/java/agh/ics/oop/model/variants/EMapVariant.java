package agh.ics.oop.model.variants;

public enum EMapVariant {
    STANDARD,
    FIRE;
}
