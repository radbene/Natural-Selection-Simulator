package agh.ics.oop.model;

import agh.ics.oop.Simulation;

public class WorldObserver {
    public WorldObserver(AbstractWorldMap map, Simulation sim) {
    }

    public void update() {
    }
}
