package agh.ics.oop.model;

public class GrassSpawner {
    public GrassSpawner(AbstractWorldMap map) {
    }

    public void spawnGrass(int n) {
        // grass should be spawned with probability of 80% in equator and 20% in other places (position must not be already taken)
    }
}
